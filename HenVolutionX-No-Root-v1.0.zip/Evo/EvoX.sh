#!/system/bin/sh
export red="\033[1;31m"
export green="\033[1;32m"
export yellow="\033[1;33m"
export blue="\033[1;34m"
export purple="\033[1;35m"
export cyan="\033[1;36m"
export grey="\033[0;37m"
export bgred="\033[41m"
export bgreen="\033[42m"
export bgyellow="\033[43m"
export bgblue="\033[44m"
export bgpurple="\033[45m"
export bgcyan="\033[46m"
export bgputih="\033[47m"
ecolor="\e[0m"
bold="\e[1m"
Versi=1.0 Beta
BASEDIR="$(dirname "$0")"
server_name=$(hostname)
if [ "$(id -u)" -ne 2000 ]; then
    echo "Server Shizuku Not Running"
    exit 1
fi
incorrect_choiche() {
  echo "\n${bold}${red}[X]${ecolor} Invalid Choice."
  sleep 2
  sh /sdcard/Evo/EvoX.sh
}
clear
function showmenu() { 
echo "\n"
echo "┏┓╋┏┓╋╋╋╋╋┏━━━┓o\n┃┃╋┃┃╋╋╋╋╋┃┏━━┛\n┃┗━┛┣━━┳━┓┃┗━━┳┓┏┳━━┓\n┃┏━┓┃┃━┫┏┓┫┏━━┫┗┛┃┏┓┃\n┃┃╋┃┃┃━┫┃┃┃┗━━╋┓┏┫┗┛┃\n┗┛╋┗┻━━┻┛┗┻━━━┛┗┛┗━━┛"
echo ""
echo "Welcome To HenVolutionX\nVersi : ${Versi}\nDev : @HenVx\nNEXT-GEN MENU\n"
echo "[1].Open Menu"
echo "[2].Grup Telegram"
echo "[3].Support HenVx"
echo "[4].Exit"
echo -n "\n${bold}[+]${ecolor} ${bold}${bgreen} Select [1-4] ${ecolor}: " 
read choice
     case $choice in
     1) #MenuEcho
        clear
        OpenMenu1() {
        echo "╔═══╦╗──╔╦═══╗╔═╗╔═╦═══╦═╗─╔╦╗─╔╗\n║╔══╣╚╗╔╝║╔═╗║║║╚╝║║╔══╣║╚╗║║║─║║\n║╚══╬╗║║╔╣║─║║║╔╗╔╗║╚══╣╔╗╚╝║║─║║\n║╔══╝║╚╝║║║─║║║║║║║║╔══╣║╚╗║║║─║║\n║╚══╗╚╗╔╝║╚═╝║║║║║║║╚══╣║─║║║╚═╝║\n╚═══╝─╚╝─╚═══╝╚╝╚╝╚╩═══╩╝─╚═╩═══╝"
        echo ""
        echo " -Extended Menu- "
        echo " [A].Mode Performance"
        echo " [B].Mode Daily "
        echo " [C].Mode Performance Extreme "
        echo ""
        echo " -Android Setting- "
        echo " [D].Density Custom"
        echo " [E].Thermal Temp Custom"
        echo " [F].Back To Main Menu"
        echo -n "\n${bold}[+]${ecolor} ${bold}${bgreen} Select [A-F] ${ecolor}: " 
        read choice
             case $choice in
             A)
               echo "\nSelected Mode Performance"
               set_performance() {
               setprop debug.choreographer.skipwarning 12500000
               setprop debug.egl.buffcount 4
               setprop debug.dev.ssrm.turbo true
               setprop debug.enabletr true
               setprop debug.rs.default-CPU-buffer 65536
               setprop debug.fb.rgb565 1
               setprop debug.disable.computedata true
               setprop debug.lldb-rpc-server 0
               setprop debug.qctwa.preservebuf 1
               setprop debug.app.performance_restricted false
               setprop debug.mdlogger.Running 0
               setprop debug.power.profile high_performance
               setprop debug.performance.tuning 1
               setprop debug.cpuprio 7 
               setprop debug.gpuprio 7 
               setprop debug.ioprio 7
               setprop debug.performance_schema 1
               setprop debug.performance_schema_max_memory_classes 320
               setprop debug.gpu.scheduler_pre.emption 1
               setprop debug.stagefright.c2inputsurface -1
               setprop debug.stagefright.ccodec 4
               setprop debug.stagefright.omx_default_rank 512
               setprop debug.performance_schema_max_socket_classes 10 
               setprop debug.sdm.disable_skip_validate 1
               setprop debug.egl.native_scaling true
               setprop debug.multicore.processing 1
               setprop debug.OVRManager.cpuLevel 1
               setprop debug.OVRManager.gpuLevel 1
               setprop debug.gralloc.gfx_ubwc_disable false
               setprop debug.mdpcomp.mixedmode false
               setprop debug.hwc.fbsize XRESxYRES
               setprop debug.sdm.support_writeback 1
               setprop debug.power_management_mode pref_max
               settings put global activity_manager_constants 1
               setprop debug.gr.swapinterval -1 
               setprop debug.hwui.disabledither false 
               setprop debug.disable.hwacc 0 
               setprop debug.disable_sched_boost true 
               setprop debug.javafx.animation.fullspeed true 
               setprop debug.rs.default-CPU-driver 1 
               setprop debug.MB.inner.running 24
               setprop debug.MB.running 72
               setprop debug.hwui.render_dirty_regions false
               setprop debug.hwc.bq_count 3 
               setprop debug.hwui.target_cpu_time_percent 100
               setprop debug.hwui.target_gpu_time_percent 100
               }
               set_performance > /dev/null 2>&1 
               sleep 1
               echo "Succes Instaling"
               clear 
               sleep 1
               OpenMenu1
               ;;
             B)
               echo "\nSelected Mode Daily"
               set_daily() {
               setprop debug.hwui.target_cpu_time_percent 50
               setprop debug.hwui.target_gpu_time_percent 50
               }
               set_daily > /dev/null 2>&1 
               sleep 1
               echo "Succes Instaling"
               clear 
               sleep 1
               OpenMenu1
               ;;
             C)
               echo "\nSelected Mode Performance Extreme"
               set_extrime() {
               setprop debug.choreographer.skipwarning 12500000
               setprop debug.egl.buffcount 4
               setprop debug.dev.ssrm.turbo true
               setprop debug.enabletr true
               setprop debug.rs.default-CPU-buffer 65536
               setprop debug.fb.rgb565 1
               setprop debug.disable.computedata true
               setprop debug.lldb-rpc-server 0
               setprop debug.qctwa.preservebuf 1
               setprop debug.app.performance_restricted false
               setprop debug.mdlogger.Running 0
               setprop debug.power.profile high_performance
               setprop debug.performance.tuning 1
               setprop debug.cpuprio 8
               setprop debug.gpuprio 8
               setprop debug.ioprio 8
               setprop debug.performance_schema 1
               setprop debug.performance_schema_max_memory_classes 320
               setprop debug.gpu.scheduler_pre.emption 1
               setprop debug.stagefright.c2inputsurface -1
               setprop debug.stagefright.ccodec 4
               setprop debug.stagefright.omx_default_rank 512
               setprop debug.performance_schema_max_socket_classes 10 
               setprop debug.sdm.disable_skip_validate 1
               setprop debug.egl.native_scaling true
               setprop debug.multicore.processing 1
               setprop debug.OVRManager.cpuLevel 1
               setprop debug.OVRManager.gpuLevel 1
               setprop debug.gralloc.gfx_ubwc_disable false
               setprop debug.mdpcomp.mixedmode false
               setprop debug.hwc.fbsize XRESxYRES
               setprop debug.sdm.support_writeback
               setprop debug.gr.swapinterval -1 
               setprop debug.hwui.disabledither false 
               setprop debug.disable.hwacc 0 
               setprop debug.disable_sched_boost true 
               setprop debug.javafx.animation.fullspeed true 
               setprop debug.rs.default-CPU-driver 1 
               setprop debug.MB.inner.running 24
               setprop debug.MB.running 187
               setprop debug.hwui.render_dirty_regions false
               setprop debug.hwc.bq_count 3 
               setprop debug.hwui.target_cpu_time_percent 100
               setprop debug.hwui.target_gpu_time_percent 100
               cmd power set-fixed-performance-mode-enabled true
               cmd power set-adaptive-power-saver-enabled true
               }
               set_extrime > /dev/null 2>&1
               sleep 1
               echo "Succes Instaling"
               clear 
               sleep 1
               OpenMenu1
               ;;
             D)
               echo "\nSelected Density Custom"
               sleep 2
               echo ""
               echo "Input DPI settings "
               echo "Example 360 For 800 DPI " 
               while true; do
               echo -n "DPI : "
               read num
               if echo "$num" | grep -q '^[0-9][0-9]*$'; then
                break
               else
                echo ""
                echo "Invalid format. Please enter a valid number."
               fi
               done
               echo ""
               echo "Setting display to $num density done"
               echo ""
               (
               wm density "$(($num))"
               )> /dev/null 2>&1 
               sleep 1
               clear 
               sleep 1
               OpenMenu1
               ;;
             E)
               echo "\nSelected Thermal Temp Custom"
               sleep 2
               echo ""
               echo "Input Thermal Temperatur "
               echo "Example 40° For 90° Temp " 
               while true; do
               echo -n "Set : "
               read num
               if echo "$num" | grep -q '^[0-9][0-9]*$'; then
                break
               else
                echo ""
                echo "Invalid format. Please enter a valid number."
               fi
               done
               echo ""
               echo "Setting thermal temp $num° done"
               echo ""
               (
               cmd device_config put thermal high_temp_limit "$(($num))"
               )> /dev/null 2>&1 
               sleep 5
               clear 
               sleep 1
               OpenMenu1
               ;;
             F)
               clear
               sleep 1
               showmenu
               ;;
             R)
               clear
               sleep 1
               sh /sdcard/EvoX.sh
               ;;
             *)
               incorrect_choiche
               ;;
             esac
        }
        clear
        sleep 0.5
        OpenMenu1
        ;;
     2)
        #NoName
        ;;
     3)
        #NoName
        ;;
     4)
        sleep 1
        echo "\nThanks For Using My Menu\n"
        echo "\nJoin My Telegram HenVx SC\n"
        sleep 1
        exit 1
        #Lu Bisa Rubah Sesuka Hati
        ;;
     R)
        clear
        sleep 1
        sh /sdcard/Evo/EvoX.sh
        ;;
     *)
        incorrect_choiche
        ;;
     esac
}
clear
sleep 1
showmenu
# credits @jjogit